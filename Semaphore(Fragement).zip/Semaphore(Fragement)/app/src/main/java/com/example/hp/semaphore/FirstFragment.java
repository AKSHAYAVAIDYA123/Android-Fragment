package com.example.hp.semaphore;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by HP on 13-01-2018.
 */

public class FirstFragment extends Fragment {
    View myView;
    @Nullable

    Button button;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.first_layout, container, false);
        Button button = (Button) myView.findViewById(R.id.button);
        Button button2 = (Button) myView.findViewById(R.id.button2);
        button.setOnClickListener(new OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Day1.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Day2Activity.class);
                startActivity(intent);
            }
        });
        return myView;
    }
    public void goToAttract(View v)
    {

    }

}
