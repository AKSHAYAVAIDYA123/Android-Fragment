package com.example.hp.semaphore;

import android.app.Fragment;
import android.app.usage.UsageEvents;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by HP on 13-01-2018.
 */

public class thirdFragment extends Fragment {
    View myView;
    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myView = inflater.inflate(R.layout.third_layout,container,false);
        Button button = (Button) myView.findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Quiz.class);
                startActivity(intent);
            }
        });
        Button button1 = (Button) myView.findViewById(R.id.button3);
        button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),coding.class);
                startActivity(intent);
            }
        });
        Button button5 = (Button) myView.findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),IT_Manager.class);
                startActivity(intent);
            }
        });
        Button button6 = (Button) myView.findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),DBMS.class);
                startActivity(intent);
            }
        });
        Button button7 = (Button) myView.findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Product.class);
                startActivity(intent);
            }
        });
        Button button8 = (Button) myView.findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Video.class);
                startActivity(intent);
            }
        });
        Button button9 = (Button) myView.findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Tresure.class);
                startActivity(intent);
            }
        });
        Button button10 = (Button) myView.findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Gaming.class);
                startActivity(intent);
            }
        });
        Button button11 = (Button) myView.findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),web.class);
                startActivity(intent);
            }
        });
        Button button12 = (Button) myView.findViewById(R.id.button12);
        button12.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                Intent intent=new Intent(getActivity(),Culture.class);
                startActivity(intent);
            }
        });

        return myView;
    }
}
